/*
 * 
 * What happens when we're done evaluating (i.e. we've reached as high as we'll go)?
 * 	Timer MUST be killed to prevent infinite loop scenario.
 * 	At the least a Boolean condition should prevent the whole evaluation from rerunning if not ready.
 * 
 * 
 * 
 * */




package HillClimberPkg;

import java.util.TimerTask;

public class HillClimber extends TimerTask{

	private boolean isNotFinished = true;
	
	private int currentPos = 0;
	private int currentPosWeight = 0;
	private int highestNeighborPos = 0;
	private int highestNeighborWeight = 0;
	
	
	
	
	public HillClimber(HillField hf, int startingPos){
		this.currentPos = startingPos;
		this.currentPosWeight = ((HillStep)hf.getChildrenUnmodifiable().get(startingPos)).getWeight();
		((HillStep)hf.getChildrenUnmodifiable().get(startingPos)).setChosen(true);
	} // END
	
	
	
	
	public void evaluate(HillField hf){
		
		// Get indicies of current neighbors.
		int[] neighborIndicies = hf.getValidMoves(currentPos);
		
		// Check to see which neighbor has the highest value.
		for(int i=0; i<neighborIndicies.length; i++){
			// Is the neighbor position a valid one?
			if(neighborIndicies[i] != -1){
				// Show user what space is under consideration.
				((HillStep)hf.getChildrenUnmodifiable().get(neighborIndicies[i])).setConsidered(true);
				// Is the neighbor position's weight value greater than record?
				if(((HillStep)hf.getChildrenUnmodifiable().get(neighborIndicies[i])).getWeight() > highestNeighborWeight){
					highestNeighborPos = neighborIndicies[i];
					highestNeighborWeight = ((HillStep)hf.getChildrenUnmodifiable().get(neighborIndicies[i])).getWeight();
				}
				// Show user that the considered space is no longer under analysis.
				((HillStep)hf.getChildrenUnmodifiable().get(neighborIndicies[i])).setConsidered(false);
			}
		} // for i
		
		if(highestNeighborWeight > currentPosWeight){
			currentPos = highestNeighborPos;
			currentPosWeight = highestNeighborWeight; 
			((HillStep)hf.getChildrenUnmodifiable().get(currentPos)).setChosen(true);

		}
		else{
			((HillStep)hf.getChildrenUnmodifiable().get(currentPos)).setGoal(true);
			isNotFinished = false;
		}
		
		
		
		
	} // END
	
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		if(isNotFinished){
			//evaluate(hf);
		}
		else{
			// kill timer
		}
	} // END
	
	
	
	

	
	
	
	
	
	
} // END
