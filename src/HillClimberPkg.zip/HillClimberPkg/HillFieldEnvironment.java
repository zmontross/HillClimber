package HillClimberPkg;

import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.control.Button;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.control.ToolBar;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;

public class HillFieldEnvironment extends Group {

	
	private Boolean isSetStartPos = false;
	private Boolean isSetGoalPos = false;
	
	private int startPosIndex = -1;
	private int goalPosIndex = -1;
	
	private String strDebugInfo = 
					"Coords: x , y\n"
					+ "HillField"
					+ "\n\n"
					+ "Adjacent indicies to x|y(i)"
					+ ":\n\tiiup, iidn, iilf, iirt";
	
	private Label lblDebugInfo = new Label( strDebugInfo ); 

	private Button btnRandColor = new Button("Randomize Colors");
	private Button btnRandHeights = new Button("Randomize Heights");
	private Button btnSubmitParams = new Button("Submit");
	private Button btnSetStart = new Button("Set Start");
	private Button btnSetGoal = new Button("Set Goal");
	private Button btnResetField = new Button("Reset");
	private Button btnToggleDebugInfo = new Button("Toggle Debug Info");
	
	private ComboBox<Integer> cbHeightLimit = new ComboBox<Integer>();
	private ComboBox<Integer> cbSquares = new ComboBox<Integer>();
	
	private ColorPicker colorpicker = new ColorPicker();
	
	private ToolBar tb;
	
	private HillField hf;
	private HillColorKey hck;
	
	public HillFieldEnvironment(){
		this(HillField.getSizeDefault(), HillField.getSquaresDefault(), HillField.getWeightLimitDefault());
	}
	
	
	public HillFieldEnvironment(double size, int squares, int weightLimit){

		this.hf = new HillField(size, squares, weightLimit);
		this.hck = new HillColorKey(this.hf.getColorProgArray(), false);
		this.tb = new ToolBar();
		toolbarAssemble(tb, false);
		
		this.btnRandColor.setOnAction(e -> eventRegenRandColor());
		this.btnRandHeights.setOnAction(e -> eventRegenRandHeights());
		this.btnSubmitParams.setOnAction(e -> eventSubmitParams());
		this.btnSetStart.setOnAction(e -> eventSetStart());
		this.btnSetGoal.setOnAction(e -> eventSetGoal());
		this.btnResetField.setOnAction(e -> eventResetField());
		this.btnToggleDebugInfo.setOnAction(e -> eventToggleDebugInfo());
		this.colorpicker.setOnAction(e -> eventColorPicker());
		this.colorpicker.setValue(this.hf.getTileColorPrimary());
		this.lblDebugInfo.setVisible(false);
		
		this.hf.setOnMouseClicked(e -> eventHillFieldMouseClick(e));
		
		this.hck.setMaxHeight(this.hf.getSize());
		this.tb.setMaxHeight(this.hf.getSize());
		
		HBox hbox = new HBox(this.hf, this.hck, this.tb);
		hbox.setAlignment(Pos.TOP_LEFT);
		
		this.getChildren().add(hbox);
		
	} // END
	
	
	
	
	
	
	public HillField getHillField(){
		return this.hf;
	} // END
	
	public HillColorKey getHillColorKey(){
		return this.hck;
	} // END
	
	public ToolBar getHillToolBar(){
		return this.tb;
	} // END
	
	public String getDebugInfo(){
		return this.strDebugInfo;
	} // END
	
	
	private void eventRegenRandColor(){
		this.hf.regenColors(this.hf);
		this.hck.refresh(this.hf.getColorProgArray());
		this.colorpicker.setValue(this.hf.getTileColorPrimary());
	} // END
	
	private void eventRegenRandHeights(){
		this.hf.regenRandWeights(this.hf);
	} // END
	
	private void eventSubmitParams(){
		// Parse text to integers.
		int weightLimit = (int) this.cbHeightLimit.getSelectionModel().getSelectedItem();
		int squares = (int) this.cbSquares.getSelectionModel().getSelectedItem();
		// Regenerate all weights and squares.
		this.hf.regenEntireField(weightLimit, squares);
		// Refresh the color key.
		this.hck.refresh(this.hf.getColorProgArray());
	} // END
	
	private void eventSetStart(){
		if(this.isSetGoalPos){
			this.isSetGoalPos = false;
		}
		
		this.isSetStartPos = true;
	} // END
	
	private void eventSetGoal(){
		if(this.isSetStartPos){
			this.isSetStartPos = false;
		}
		
		this.isSetGoalPos = true;
	} // END
	
	private void eventResetField(){
		
		int count = this.hf.getChildrenUnmodifiable().size();
		
		for(int i=0; i<count; i++){
			((HillStep) this.hf.getChildren().get(i)).resetFlags();
		}
		
		// Reset to initial conditions
		startPosIndex = -1;
		goalPosIndex = -1;

	} // END
	
	private void eventToggleDebugInfo(){
		if(this.lblDebugInfo.isVisible()){
			this.lblDebugInfo.setVisible(false);
		}
		else{
			this.lblDebugInfo.setVisible(true);
		}
	} // END
	
	private void eventColorPicker(){
		this.hf.refreshColors(this.colorpicker.getValue());
		this.hck.refresh(this.hf.getColorProgArray());
	} // END
	
	
	
	private void eventHillFieldMouseClick(MouseEvent e){
		if(e.getButton() == MouseButton.PRIMARY){
			if(isSetStartPos){
				// Set new location as start position.
				((HillStep) this.hf.getChildren().get(this.hf.getLastModifiedIndex())).setStart(true);
				// Remove old location's start position flag.
				if(startPosIndex != -1){
					((HillStep) this.hf.getChildren().get(startPosIndex)).setStart(false);
				}
				// Record location of current start position.
				startPosIndex = this.hf.getLastModifiedIndex();
				isSetStartPos = false;
			}
			else if(isSetGoalPos){
				// Set new location as goal position.
				((HillStep) this.hf.getChildren().get(this.hf.getLastModifiedIndex())).setGoal(true);
				// Remove old location's goal position flag.
				if(goalPosIndex != -1){
					((HillStep) this.hf.getChildren().get(goalPosIndex)).setGoal(false);
				}
				// Record location of current goal position.
				goalPosIndex = this.hf.getLastModifiedIndex();
				isSetGoalPos = false;
			}
		}
		
		int[] test = this.hf.getValidMoves(this.hf.getLastModifiedIndex());
		strDebugInfo = "Coords: " + this.hf.getLastModifiedX() + " , " + this.hf.getLastModifiedY() + "\n"
				+ this.hf.getChildrenUnmodifiable().get(this.hf.getLastModifiedIndex()).toString()
				+ "\n\n"
				+ "Adjacent to " + this.hf.getLastModifiedX() + "|" + this.hf.getLastModifiedY() + "("+ this.hf.getLastModifiedIndex() + ")"
				+ ":\n\t" + test[0] + "up, " + test[1] + "dn, " + test[2] + "lf, " + test[3] + "rt";
		System.out.println(strDebugInfo);
		if(lblDebugInfo.isVisible()){
			this.lblDebugInfo.setText( strDebugInfo );
		}
	} // END
	
	
	
	
	
	
	private void toolbarAssemble(ToolBar tb, Boolean isHorizontal){
	
		if(!isHorizontal){
			tb.setOrientation(Orientation.VERTICAL);
		}
		
		
		// Set the options available for cbWeighLimit
		for(int i=HillField.getWeightLimitMin(); i<HillField.getWeightLimitMax(); i++){
			this.cbHeightLimit.getItems().add(i - HillField.getWeightLimitMin(), i);
			// Check for default value. Select if found.
			if(i == HillField.getWeightLimitDefault()){
				this.cbHeightLimit.getSelectionModel().clearAndSelect(i - HillField.getWeightLimitMin());
			}
		} // for i
		
		
		// Set the options available for cbSquares
		for(int i=this.hf.getSquaresMin(); i<this.hf.getSquaresMax(); i++){
			this.cbSquares.getItems().add(i - this.hf.getSquaresMin(), i);
			// Check for default value. Select if found.
			if(i == HillField.getSquaresDefault()){
				this.cbSquares.getSelectionModel().clearAndSelect(i - this.hf.getSquaresMin());
			}
		} // for i
		
		
		tb.getItems().addAll(
				new Label("Field Adjustments\n"),
				new Separator(),
				new Label("\nRandomizers"),
				this.btnRandColor,
				this.btnRandHeights,
				new Separator(),
				new Label("\nManual Adjustments"),
				new Label("Max Height"),
				this.cbHeightLimit,
				new Label("Squares per Side"),
				this.cbSquares,
				this.btnSubmitParams,
				new Label("Current Color"),
				colorpicker,
				new Separator(),
				new Label("\nPosition Adjustment"),
				this.btnSetStart,
				this.btnSetGoal,
				this.btnResetField,
				new Separator(),
				btnToggleDebugInfo,
				lblDebugInfo
				);

	} // END
	
	
	
	
	
} // END
