package HillClimberPkg;

import java.util.ArrayList;
import java.util.Random;

import javafx.scene.Group;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;

public class HillField extends Group{

	private static final int BASE_16_HEX = 16;						// Value used for parsing and altering color values.
	private static final int WEIGHT_LIMIT_MAX = 99;					// Absolute limit for the weightLimit parameter. All weight values must not exceed this value.
	private static final int WEIGHT_LIMIT_MIN = 5;					// Absolute minimum for the weightLimit parameter.
	private static final int WEIGHT_LIMIT_DEFAULT = 10;				// Default value for weightLimit.
	
	private static final int SQUARES_MAX = 99;						// Absolute limit for the squares parameter.
	private static final int SQUARES_MIN = 4;						// Absolute minimum for the squares parameter.
	private static final int SQUARES_DEFAULT = 10;					// Default value for the squares parameter.
	
	private static final double SIZE_DEFAULT = 600.0;				// Default value for the size (px) parameter. 
	
	private int coordX = 0;											// Grid's x-coordinate of the last-clicked-upon HillStep.
	private int coordY = 0;											// Grid's y-coordinate of the last-clicked-upon HillStep.
	private int index = 0;											// Index value of the last-clicked-upon HillStep contained within the Group node.
	private int weightLimit = WEIGHT_LIMIT_DEFAULT;					// Upper limit of weight values.
	private int squares = SQUARES_DEFAULT;							// Local value of the given input 'squares'.
	
	private double size = SIZE_DEFAULT;								// Local value N of the NxN size of the HillField in pixels. 
	private double hillStepSize;									// Local value of the size of the generated HillSteps.
		
	private boolean useRandPrimaryColor = true;						// Local value of the boolean useRandPrimaryColor (Use Random Primary Color).
	private boolean useRandWeights = true;							// Local value of the boolean useRandWeights (Use Random Weights).
	//private boolean showDetailedDebugInfo = true;					// Determines verbosity of console-printed information. CURRENTLY UNUSED.
	
	private int[][] weights;										// Used to store weight values for all HillSteps.
	private ArrayList<Paint> colorProg = new ArrayList<Paint>();	// Used to store color values that are later passed to all HillStep objects based on their weight values.
	
	private Paint tileColorPrimary;
	
	
	
	/**
	 * HillField. An NxN grid of HillStep objects.
	 * */
	public HillField(){
		this(SIZE_DEFAULT, SQUARES_DEFAULT, WEIGHT_LIMIT_DEFAULT, true, true);
	} // END
	
	
	/**
	 * HillField. An NxN grid of HillStep objects.
	 * Weight values are randomly generated inclusively-between zero and weightLimit. Colors are also randomly generated.
	 * @param size Size of the grid in pixels. HillStep squares are scaled to fit within this size.
	 * @param squares Number N of HillStep objects along one side. Actual density of grid is NxN.
	 * @param weightLimit The maximum weight value for HillSteps. Calculations with weights will use this as a maximum possible value. Minimum possible is zero. 
	 * */
	public HillField(double size, int squares, int weightLimit){
		this(size, squares, weightLimit, true, true);
	} // END
	
	
	/**
	 * HillField. An NxN grid of HillStep objects.
	 * @param size Size of the grid in pixels. HillStep squares are scaled to fit within this size.
	 * @param squares Number N of HillStep objects along one side. Actual density of grid is NxN.
	 * @param weightLimit The maximum weight value for HillSteps. Calculations with weights will use this as a maximum possible value. Minimum possible is zero.
	 * @param useRandPrimaryColor If true, a random primary color will be chosen for the grid's color set. This will be the "highest hill" color.
	 * @param useRandWeights If true, the grid's values will be comprised of random values inclusively-between 0 and weightLimit. 
	 * */
	public HillField(double size, int squares, int weightLimit, boolean useRandPrimaryColor, boolean useRandWeights){

		// Store given attributes' values.
		this.squares = squares;
		this.size = size;
		this.weightLimit = weightLimit;
		this.useRandPrimaryColor = useRandPrimaryColor;
		this.useRandWeights = useRandWeights;
		this.hillStepSize = size / squares;
		this.weights = new int[squares][squares];
		
		// Limit the weight limit should the given value exceed the absolute limit.
		if(this.weightLimit > WEIGHT_LIMIT_MAX)
			this.weightLimit = WEIGHT_LIMIT_MAX;
		
		// Shall a random color be generated, or will the user specify a color?
		if(this.useRandPrimaryColor)
			this.tileColorPrimary = generateRandPrimaryTileColor(); 
		else
			this.tileColorPrimary = generateRandPrimaryTileColor();		// To be fixed later on when in-app user-customization is added-in.
		
		// Shall the field be generated using a random distribution of randomly-generated weight values?
		if(this.useRandWeights)
			generateWeightsRand(weights, weightLimit);
		else
			generateWeightsRand(weights, weightLimit);			// To be fixed later on when in-app user-customization is added-in.

		generateColorProgression(tileColorPrimary);
		
		populateHillSteps(this);

		// Assign all HillSteps within this HillField their colors and weights. 
		linkWeightColors(this);
		
		// Dump information to console.
		printWeightsArray();
		printColorProgArray();
	} // END
	
	
	
	

	
	
	
	
	
	//##### Get #####
	/**
	 * Returns the index of the HillStep within the one-dimensional Group which stores the HillStep objects.
	 * */
	public int getLastModifiedIndex(){
		return index;
	} // END
	
	/**
	 * Returns the x-coordinate TRANSLATION of the one-dimensional Group storing the HillStep objects.
	 *  Note: This will not reference the actual object if used. Instead, it is primarily useful for graphical information given to users.
	 * */
	public int getLastModifiedX(){
		return coordX;
	} // END
	
	/**
	 * Returns the y-coordinate TRANSLATION of the one-dimensional Group storing the HillStep objects.
	 *  Note: This will not reference the actual object if used. Instead, it is primarily useful for graphical information given to users.
	 * */
	public int getLastModifiedY(){
		return coordY;
	} // END
		
	
	/**
	 * Returns the pixel size of one side of the HillField.
	 * */
	public double getSize(){
		return this.size;
	}
	
	/**
	 * Returns the default pixel size of one side of the HillField.
	 * */
	public static double getSizeDefault(){
		return SIZE_DEFAULT;
	}
	
	/**
	 * Returns the number of squares (a.k.a. HillSteps) on a side of the grid.
	 * */
	public int getSizeSquares(){
		return this.squares;
	} // END
	
	/**
	 * Returns the size of the HillStep objects contained in the HillField.
	 * */
	public double getSizeHillSteps(){
		return this.hillStepSize;
	} // END
	
	/**
	 * Returns an integer value weightLimit, the highest possible value in the HillField.
	 * */
	public int getWeightLimit(){
		return weightLimit;
	} // END
	
	/**
	 * Returns the size of the color progression array as an integer.
	 * */
	public int getColorProgSize(){
		return colorProg.size();
	} // END
	
	/**
	 * Returns a specific Paint object stored within the color progression array.
	 * Note that the array is an ArrayList<T> and will respond to invalid indicies as such.
	 * @param index Index value of the desired Paint object within the color progression array.
	 * */
	public Paint getColorProgSingle(int index){
		return colorProg.get(index);
	} // END
	
	/**
	 * Returns the absolute maximum value usable for the weight limit value.
	 * */
	public static int getWeightLimitMax(){
		return WEIGHT_LIMIT_MAX;
	} // END
	
	/**
	 * Returns the absolute minimum value usable for the weight limit value.
	 * */
	public static int getWeightLimitMin(){
		return WEIGHT_LIMIT_MIN;
	} // END
	
	/**
	 * Returns the default value usable for the weight limit value.
	 * */
	public static int getWeightLimitDefault(){
		return WEIGHT_LIMIT_DEFAULT;
	} // END
	
	/**
	 * Returns the absolute maximum value usable for the squares value.
	 * */
	public int getSquaresMax(){
		return SQUARES_MAX;
	} // END
	
	/**
	 * Returns the absolute minimum value usable for the squares value.
	 * */
	public int getSquaresMin(){
		return SQUARES_MIN;
	} // END
	
	/**
	 * Returns the default value usable for the squares value.
	 * */
	public static int getSquaresDefault(){
		return SQUARES_DEFAULT;
	} // END
	
	/**
	 * Returns the current value of the primary tile color.
	 * */
	public Color getTileColorPrimary(){
		return (Color)this.tileColorPrimary;
	} // END
	
	/**
	 * 
	 * */
	public int[] getValidMoves(int position){
		
		int[] validMoves = {-1, -1, -1, -1};
		
		int squares = this.getSizeSquares();
		
		int upIndex = position - squares;
		int downIndex = position + squares;
		int leftIndex = position - 1;
		int rightIndex = position + 1;
		
		if(upIndex >= 0){
			validMoves[0] = upIndex;
		}
		
		if(downIndex < (this.getSizeSquares() * this.getSizeSquares())){
			validMoves[1] = downIndex;
		}

		if((leftIndex / squares) == (this.getLastModifiedY())){
			validMoves[2] = leftIndex;
		}
		
		if((rightIndex / squares) == (this.getLastModifiedY())){
			validMoves[3] = rightIndex;
		}
		
		return validMoves;
	} // END
	
	/**
	 * Sets the currently-used value of the primary tile color.
	 * */
	public void setTileColorPrimary(Paint color){
		this.tileColorPrimary = color;
	} // END
	
	/**
	 * Returns color progression ArrayList<Paint>.
	 * */
	public ArrayList<Paint> getColorProgArray(){
		return this.colorProg;
	} // END

	//##### Misc Methods #####
	/**
	 * Generates weight values for a given two-dimensional Integer array.
	 * @param weights This two-dimensional Integer array is where generated values are stored.
	 * @param length This value is the NxN side-length of the array. Note, this value should be set equal to the number of HillSteps per side of the HillField.
	 * @param limit This is the upper limit value for the generated weight values. Integers from zero up to and including this value will be used.
	 * */
	public void generateWeightsRand(int[][] weights, int limit){
		
		Random r = new Random();
		
		for(int i=0; i<(this.getSizeSquares()); i++){
			// For ROWS
			for(int j=0; j<(this.getSizeSquares()); j++){
				// For COLUMNS
				weights[i][j] = r.nextInt(limit+1);
			} // For j
		} // For i
		
	} // END
	
	/**
	 * Generates the progression of colors used by the array. The color values are stored in their own array local to the HillField.
	 * @param limit This is the upper-limit to weight values. This is used to limit the number of color values generated.
	 * @param HillColor This is a Paint value that is used as the high-weight-color. The other lower-weight-colors are generated from this original color.
	 * */
	public void generateColorProgression(Paint HillColor){
		String colorStr, redHex, greenHex, blueHex;
		int redMax, greenMax, blueMax, redDec, greenDec, blueDec, redVal, greenVal, blueVal;
		
		// Clear the color progression array
		this.colorProg.clear();
		
		colorStr = HillColor.toString();
		
		redHex = colorStr.substring(2, 4);
		greenHex = colorStr.substring(4, 6);
		blueHex = colorStr.substring(6, 8);
		
		redMax = Integer.valueOf(redHex, BASE_16_HEX);
		greenMax = Integer.valueOf(greenHex, BASE_16_HEX);
		blueMax = Integer.valueOf(blueHex, BASE_16_HEX);
		
		redDec = redMax / this.weightLimit;
		greenDec = greenMax / this.weightLimit;
		blueDec = blueMax / this.weightLimit;
				
		for(int weight=0; weight<this.weightLimit; weight++){
			
			redVal = redMax - (redDec * (this.weightLimit - weight));
			greenVal = greenMax - (greenDec * (this.weightLimit - weight));
			blueVal = blueMax - (blueDec * (this.weightLimit - weight));
			
			colorProg.add(Color.rgb(redVal, greenVal, blueVal));
			
		} // for weight
		
		colorProg.add(HillColor);
		
	} // END
	
	
	/**
	 * Generates a random color for the primary HillStep color from which all their colors will be derived.
	 * */
	private Paint generateRandPrimaryTileColor(){
		
		Paint color = Color.rgb(new Random().nextInt(255), new Random().nextInt(255), new Random().nextInt(255));
	
		// Code for detecting unwanted dark hues will go here...
		
		return color;
	} // END
	
	
	/**
	 * Populates the given HillField with HillStep objects.
	 * @param hf HillField of choice.
	 * */
	private void populateHillSteps(HillField hf){
		
		hf.getChildren().clear();
		
		hf.hillStepSize = size / squares;
		
		// Generate HillSteps and populate the HillField.
		for(int hfCols=0; hfCols<hf.getSizeSquares(); hfCols++){
			// For each COLUMN
			for(int hfRows=0; hfRows<hf.getSizeSquares(); hfRows++){
				// For each ROW
				HillStep hs = new HillStep((hf.getSizeHillSteps()*hfRows), (hf.getSizeHillSteps()*hfCols), hf.getSizeHillSteps(), hf.getSizeHillSteps(), hf.weights[hfCols][hfRows] , Color.GRAY); // Xpos, Ypos, Xsize, Ysize, Paint
				
				hs.setOnMouseClicked(e -> {
					index = this.getChildrenUnmodifiable().indexOf(hs);
					coordY = index / squares;
					coordX = index % squares;
				});
				hf.getChildren().add(hs);
				
			} // for hfRows
		} // for hfCols
		
		System.out.println(Integer.toString((hf.getChildren().size())) + " HillSteps populated into " + hf.getId());
	} // END
	
	
	/**
	 * Assigns weights in the given HillField's weights array.
	 * @param hf HillField object.
	 * */
	public void assignWeights(HillField hf){
		
		int coordX, coordY;
		
		for(int i=0; i<hf.getChildrenUnmodifiable().size(); i++){
			coordX = i / hf.getSizeSquares();
			coordY = i % hf.getSizeSquares();
			((HillStep) hf.getChildren().get(i)).setWeight(hf.weights[coordX][coordY]);
		} // for i
		
		System.out.println("New weights assigned to HillSteps in " + hf.getId());
	} // END
	
	
	/**
	 * This method regenerates the color set for the HillField.
	 * @param hf HillField object. 
	 * */
	public void regenColors(HillField hf){
		
		// Generate new color
		this.tileColorPrimary = generateRandPrimaryTileColor();
		
		// Refill the color progression array
		generateColorProgression(this.tileColorPrimary);
		
		// Link the field's weights to the color progression array's values
		linkWeightColors(hf);
		
		System.out.println("Color scheme regenerated for " + super.toString());
		printColorProgArray();
	} // END
	
	
	/**
	 * This method regenerates a new set of random weights for the HillField.
	 * @param hf HillField object.
	 * */
	public void regenRandWeights(HillField hf){
		
		// Generate a new set of weights.
		hf.generateWeightsRand(hf.weights, hf.getWeightLimit());
		
		// Assign new weights to each HillStep.
		assignWeights(hf);
		
		printWeightsArray();
		
		// Link weights and colors together.
		linkWeightColors(hf);
		
		System.out.println("HillField weights regenerated for " + super.toString());
		
	} // END
	
	
	
	public void regenEntireField(int weightLimit, int squares){
		this.weightLimit = weightLimit;
		this.squares = squares;
		
		this.weights = new int[squares][squares];
		
		// Clear the color progression array
		colorProg.clear();
		
		generateColorProgression(this.getTileColorPrimary());
		
		populateHillSteps(this);
		
		regenRandWeights(this); // linkWeightColors
		
		printColorProgArray();
	} // END
	
	
	/**
	 * This method adjusts the colors of this HillField's HillSteps.
	 * @param hf This is a HillField which will receive the color update.
	 * */
	public void linkWeightColors( HillField hf ){
		
		for(int i=0; i<hf.getChildrenUnmodifiable().size(); i++){
			int hsWeight = ((HillStep) hf.getChildren().get(i)).getWeight();
			((HillStep) hf.getChildren().get(i)).setBackgroundFill( colorProg.get(hsWeight) );
		}
		
	} // END

	
	/**
	 * @param color New primary title color.
	 * */
	public void refreshColors(Paint color){
		this.setTileColorPrimary(color);
		this.generateColorProgression(this.getTileColorPrimary());
		this.linkWeightColors(this);
		this.printColorProgArray();
	} // END
	
	
	/**
	 * Prints the Integer array containing the weight values for each HillStep to console.
	 * */
	private void printWeightsArray(){

		System.out.println("Weights Array:");
		
		System.out.print("\n     ");
		for(int a=0; a<this.getSizeSquares(); a++){
			if(a/10 == 0){
				System.out.print(a + "  ");
			}
			else{
				System.out.print(a + " ");
			}
		} // for a
		
		
		System.out.print("\n     ");
		for(int b=0; b<this.getSizeSquares(); b++){
			System.out.print("|" + "  ");
		} // for b
		
		
		for(int i=0; i<this.getSizeSquares(); i++){
			// For ROWS
			if(i/10 == 0){
				System.out.print("\n" + " " + i + " - ");
			}
			else{
				System.out.print("\n" + i + " - ");
			}
			
			for(int j=0; j<this.getSizeSquares(); j++){
				// ForCOLS
				
				if(weights[i][j]/10 == 0){
					System.out.print(weights[i][j] + "  ");
				}
				else{
					System.out.print(weights[i][j] + " ");
				}
			} // for j
		} // for i
		
		System.out.println("\n");
		
	} // END
	
	
	/**
	 * Prints the Paint array of color values used for each HillStep to console.
	 * */
	private void printColorProgArray(){

		String padding = "  ";
		System.out.println("Color Progression Array:");
		for(int i=0; i<colorProg.size(); i++){
			
			if(i < 10){
				padding = "  ";
			}
			else{
				padding = " ";
			}
			
			if(i == (colorProg.size() - 1)){
				System.out.println("\t" + padding + i + " -> " + colorProg.get(i).toString() + " -> Primary Color");
			}
			else{
				System.out.println("\t" + padding + i + " -> " + colorProg.get(i).toString());
			}
		} // for i
		
		System.out.println("\n");
		
	} // END
	
	
	
	/**
	 * This overridden toString() method returns the index, x-coordinate, and y-coordinate of the last HillStep to receive a mouse click event.
	 * */
	public String toString(){
		return Integer.toString(index) + "|" + Integer.toString(coordX) + ',' + Integer.toString(coordY);
	} // END
	
	
} // END