/*
 * Desired upgrades
 * 
 * -genRandPrimaryColor to include detection of color hues that are too dark.
 * 
 * -Resize grid (pixel size)
 * 		-- All HillSteps must be resized.
 *
 * -GUI: User-adjustable parameters
 * 		-- User-chosen color
 * 			--- ColorPicker object in new window which returns a Paint value.
 * 			--- Recalculate color progression array values.
 * 			--- Link weights array values to new color progression array values.
 * 
 * -Save colors and field configs.
 * 
 * -Fixed HillStep size with an HF used to display a close-up of a much larger region.
 * 		Think of how Metroid, Pokemon, Zelda, Fire Emblem, Two Brothers,
 * 			and old classic top-down RPGs handle large worlds!
 * 
 * -Set of buttons...
 * 		-- Select Algorithm
 * 		-- Select Starting Pos
 * 		-- Select Goal Pos (for appropriate algorithm)
 * 
 * -Timer to govern AI.
 * 		-- Runtime-adjustable frequency.
 * 		-- Slows-down AI to show its progress to user.
 * 		--Need to look into timeline so that I can do time stuff with JavaFX.
 * 
 * -AI
 * 		-- Timer to control algorithm-rate
 * 		-- Dropdown to select algorithm
 * 		-- "Set Start" btn to allow user to place start pos via mouse.
 * 		-- Algorithm-dependent "Set Goal" btn to allow user to place goal pos via mouse.
 * 		-- Algorithm-dependent "Set Max Traversible Steepness" to limit the delta-Weight which counts as a valid move.
 * 		-- LOCK HILL PARAMS ALTERATION WHILE RUNNING!!!!
 * 		-- Contains Timer and TimerTask objects(?). get/Set methods for checking isRunning status and changing rate of evaluations.
 *  
 * -HillField to keep track of statistics
 * 		-- All HillSteps whose booleans are true are kept track of in their own ArrayList<T>.
 * 		-- clearBooleans() methods to tell the field to reset only those steps whose booleans aren't false.
 * 		-- Record the index of the "Start Pos"
 * 		-- Record the index of the "Goal Pos"
 * 		-- (Generation-Algorithm dependent) Keep track of Global Maximum. (Algorithm-dependent) Show user AI's rating based on Max-vs-final weightings.
 * 
 * -New Class. Contains HillField, HillColorKey. Responsible for retaining data about the HillField. Clears flags. Etcetera.
 * 
 * 
 * */



package HillClimberPkg;

import java.util.Timer;
import java.util.TimerTask;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Separator;
import javafx.scene.control.SplitPane;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;


public class Main extends Application {

	
	
	private static final String APPTITLE = "Hill Climber";
	
	private static final int WINDOW_SIZE_WIDTH = 1366;
	private static final int WINDOW_SIZE_HEIGHT = 768;
	
	
	Stage window;
	Scene sceneHillField;
	Scene sceneMain;

	Label lblInstruction = new Label("Left-click on grid squares to toggle their flags' status. Right-click on titles and select Tab 2 (left) to view that grid square's information.");
	Label lblStepInfo = new Label("No grid square (HillStep) has been selected.\nRight-click on any grid square to see its information here.");

	ComboBox<Integer> cbWeightLimit = new ComboBox<Integer>();
	ComboBox<Integer> cbSquares = new ComboBox<Integer>();

	MenuBar menuBar = new MenuBar();
	SplitPane spCentralLayout = new SplitPane();

	TabPane tabpane = new TabPane();
	Rectangle ttrect = new Rectangle(50,50,Color.GOLD);
	Button ttstart = new Button("Start");
	Button ttstop = new Button("Stop");
	Timer timer = new Timer();
	Tasker tasker = new Tasker();
	ComboBox<Integer> tttimes = new ComboBox<Integer>();
	Boolean isTicking = false;
	int index = 0;

	
	HillFieldEnvironment hfe = new HillFieldEnvironment();
	
	                            
	
	public static void main(String[] args){
		launch(args);
	}
	
	
	//############### start - JavaFX prerequisite ###############

	public void start(Stage primaryStage) throws Exception {
		//##### Setup - window #####
		window = primaryStage;
		window.setTitle(APPTITLE);
		window.setWidth(WINDOW_SIZE_WIDTH);
		window.setHeight(WINDOW_SIZE_HEIGHT);
		window.setResizable(false);

	
		
		/*
		 * 
		 * GUI Setup goes below here...
		 * 
		 */

		
		
		tttimes.getItems().addAll(50, 100, 250, 500, 750, 1000, 1500, 2000, 5000);
		tttimes.getSelectionModel().clearAndSelect(0);
		tttimes.setOnAction(e -> eventTimeChange());
		
		
		hfe.setOnMouseClicked(e -> eventHillStepInfo());
		

		VBox t3Content = new VBox();
		HBox bottom = new HBox();
		
		BorderPane mainLayout = new BorderPane();
		
		Tab t1 = new Tab("App Info");
		Tab t2 = new Tab("HillStep Info");;
		Tab t3 = new Tab("Timer Experiments");
		Tab t4 = new Tab("Tab 4");
		Tab t5 = new Tab("Tab 5");
		
		t1.setContent(new Label("Select Tab 2 to view grid space information.\n\nLeft-click grid squares to toggle their flags.\n\nRight-click grid squares to generate info in Tab 2.\n\nUse the buttons on the far right to adjust the grid's current settings."));
		t2.setContent(lblStepInfo);
		t3Content.getChildren().addAll(ttrect, new Separator(), ttstart, ttstop, new Label(""), tttimes);
		t3.setContent(t3Content);
		ttstart.setOnAction(e -> eventTTStart());
		ttstop.setOnAction(e -> eventTTStop());
		t1.setClosable(false);
		t2.setClosable(false);
		t3.setClosable(false);
		t4.setClosable(false);
		t5.setClosable(false);
		
		tabpane.getTabs().addAll(t1,t2,t3,t4,t5);

		
		bottom.getChildren().addAll(lblInstruction);
		bottom.setAlignment(Pos.TOP_CENTER);
		bottom.setSpacing(10.0);
		
		spCentralLayout.getItems().addAll(tabpane, hfe);
		
		
		Menu mFile = new Menu("File");
		Menu mEdit = new Menu("Edit");
		Menu mSource = new Menu("Source");
		Menu mRefactor = new Menu("Refactor");
		Menu mNavigate = new Menu("Navigate");
		Menu mSearch = new Menu("Search");
		Menu mHillField = new Menu("HillField");
		MenuItem mi1 = new MenuItem("Do");
		MenuItem mi2 = new MenuItem("May");
		MenuItem mi3 = new MenuItem("Say");
		MenuItem mi4 = new MenuItem("Think");
		MenuItem mi5 = new MenuItem("Has");
		MenuItem mi6 = new MenuItem("Well");
		MenuItem mi7 = new MenuItem("the game");
		mFile.getItems().add(mi1);
		mEdit.getItems().add(mi2);
		mSource.getItems().add(mi3);
		mRefactor.getItems().add(mi4);
		mNavigate.getItems().add(mi5);
		mSearch.getItems().add(mi6);
		mHillField.getItems().addAll(mi7);
		menuBar.getMenus().addAll(mFile, mEdit, mSource, mRefactor, mNavigate, mSearch, mHillField);
		
		
		
		mainLayout.setTop(menuBar);
		mainLayout.setCenter(spCentralLayout);
		mainLayout.setBottom(bottom);
		BorderPane.setMargin(bottom, new Insets(10,10,10,10));
		
		sceneMain = new Scene(mainLayout);
		window.setScene(sceneMain);
		window.show();
		
		
		
		
	} // END
		
	
	
	/*
	 * 
	 * 
	 * Other methods go here...
	 * 
	 * 
	 */
	
	public void eventHillStepInfo(){
		lblStepInfo.setText( hfe.getDebugInfo() );
	} // END
	
	
	public void eventCloseProgram(){
		
	} // END
	
	
	
	/*
	 * 
	 * Need to look into timeline so that I can do time stuff with JavaFX.
	 * 
	 * */
	
	public void eventTTStart(){
		timer = new Timer();
		timer.scheduleAtFixedRate(new Tasker(), 0, tttimes.getValue());
		isTicking = true;
		System.out.println("Timer Test Start");
	} // END
	
	public void eventTTStop(){
		timer.cancel();
		timer.purge();
		isTicking = false;
		System.out.println("Timer Test Stop");
	} // END
	
	public void eventTimeChange(){
		if(isTicking){
			timer.cancel();
			timer.purge();
			isTicking = false;
			timer = new Timer();
			timer.scheduleAtFixedRate(new Tasker(), 0, tttimes.getValue());
			isTicking = true;
			System.out.println("Timer Test Period: " + tttimes.getValue());
		}
	} // END
	
	
	public class Tasker extends TimerTask{
		@Override
		public void run() {
			eventTimer();
		} // END
	} // END
	
	
	
	public void eventTimer(){
		if(ttrect.getFill() == Color.GOLD){
			ttrect.setFill(Color.BLUE);
			System.out.println("\tTimer Test -> BLUE");
		}
		else{
			ttrect.setFill(Color.GOLD);
			System.out.println("\tTimer Test -> GOLD");
		}
		
		
		((HillStep)hfe.getHillField().getChildren().get(index)).toggleConsidered();
		index++;
		if(index > hfe.getHillField().getChildrenUnmodifiable().size() - 1)
			index = 0;
	} // END
	
	
	
	
	
} // END
