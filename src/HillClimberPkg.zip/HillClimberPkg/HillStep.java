/*
 * Desired upgrades
 * 
 * */

package HillClimberPkg;

import javafx.scene.Group;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Rectangle;

public class HillStep extends Group{

	
	private static final double SIZE_MULT = 0.1875; 

	private static final Paint COLOR_CONSIDERED = Color.AQUA;
	private static final Paint COLOR_CHOSEN = Color.HOTPINK;
	private static final Paint COLOR_START = Color.YELLOW;
	private static final Paint COLOR_END = Color.ORANGERED;
	
	
	private Rectangle background;
	private Rectangle considered;
	private Rectangle chosen;
	private Rectangle start;
	private Rectangle goal;
	private int weight;
	private double size;
	
	
	/**
	 * This is the most basic unit of our HillField.
	 * @param x x-coordinate used for background rectangle.
	 * @param y y-coordinate used for background rectangle.
	 * @param width Width of the background rectangle.
	 * @param height Height of the background rectangle.
	 * @param weight Weight value used for AI pathing.
	 * @param color Background-rectangle's fill color which corresponds to its weight value.
	 * */
	public HillStep(double x, double y, double width, double height, int weight, Paint color){
		
		this.size = width;
		double subSize = width * SIZE_MULT;
		double xPosLeft = x + (width / 2) - subSize;
		double xPosRight = x + (width / 2);
		double yPosTop = y + (height / 2) - subSize;
		double yPosBtm = y + (height / 2);
		
		background = new Rectangle(x, y, width, height);
		background.setFill(color);
		background.setVisible(true);
		
		considered = new Rectangle(xPosLeft, yPosTop, subSize, subSize);
		considered.setFill(COLOR_CONSIDERED);
		considered.setVisible(false);
		
		chosen = new Rectangle(xPosRight, yPosTop, subSize, subSize);
		chosen.setFill(COLOR_CHOSEN);
		chosen.setVisible(false);
		
		start = new Rectangle(xPosLeft, yPosBtm, subSize, subSize);
		start.setFill(COLOR_START);
		start.setVisible(false);
		
		goal = new Rectangle(xPosRight, yPosBtm, subSize, subSize);
		goal.setFill(COLOR_END);
		goal.setVisible(false);
		
		this.getChildren().addAll(background, considered, chosen, start, goal);

		this.weight = weight;
		
	} // END
	
	
	
	// ##### Set #####
	public void setConsidered(boolean b){
		this.considered.setVisible(b);
	} // END
		
	public void setChosen(boolean b){
		this.chosen.setVisible(b);
	} // END
	
	public void setStart(boolean b){
		this.start.setVisible(b);
	} // END
		
	public void setGoal(boolean b){
		this.goal.setVisible(b);
	} // END
	
	public void setBackgroundFill(Paint color){
		this.background.setFill(color);
	} // END
	
	public void setWeight(int weight){
		this.weight= weight;
	} // END
	
	public void resetFlags(){
		this.setConsidered(false);
		this.setChosen(false);
		this.setStart(false);
		this.setGoal(false);
	} // END
	
	
	// ##### Toggle #####
	public void toggleConsidered(){
		this.considered.setVisible(!(considered.isVisible()));
	} // END
	
	public void toggleChosen(){
		this.chosen.setVisible(!(chosen.isVisible()));
	} // END
	
	public void toggleStart(){
		this.start.setVisible(!(start.isVisible()));
	} // END
	
	public void toggleGoal(){
		this.goal.setVisible(!(goal.isVisible()));
	} // END
	
	
	// ##### Get #####
	public Boolean getConsidered(){
		return this.considered.isVisible();
	} // END
	
	public boolean getChosen(){
		return this.chosen.isVisible();
	} // END
	
	public Boolean getStart(){
		return this.start.isVisible();
	} // END
	
	public boolean getGoal(){
		return this.goal.isVisible();
	} // END
	
	public int getWeight(){
		return this.weight;
	} // END
	
	public double getSize(){
		return this.size;
	}
	
	
	// ##### toString #####
	public String toString(){
		return super.toString() +
				"\n Considered=" + considered.visibleProperty().get() +
				"\n Chosen=" + chosen.visibleProperty().get() +
				"\n Start=" + chosen.visibleProperty().get() +
				"\n Goal=" + chosen.visibleProperty().get() +
				"\n Bkgnd=" + background.getFill() +
				"\n Weight=" + weight;
	} // END
	
} // END
